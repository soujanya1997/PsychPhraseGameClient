
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JTextArea;

public class ClientClass extends UnicastRemoteObject implements ClientInterface
{
    JList l;
    JTextArea area,area2;
    JButton question, trick, answer, exit, talk;
    ClientClass(JList l,JTextArea area, JTextArea area2, JButton question, JButton trick, JButton answer, JButton exit, JButton talk)throws RemoteException
    {
        super();
        this.l=l;
        this.area=area;
        this.area2=area2;
        this.question=question;
        this.trick=trick;
        this.answer=answer;
        this.exit=exit;
        this.talk=talk;
    }
    public void refreshArea(String msg)throws RemoteException
    {
        area.append(msg+"\n");
    }
    public void refreshArea2(String msg)throws RemoteException
    {
        area2.append(msg+"\n");
    }

    @Override
    public void refreshList(Vector<String> names) throws RemoteException {
        l.setListData(names);
    }

    @Override
    public void disableButton(String task) throws RemoteException {
        //To change body of generated methods, choose Tools | Templates.
        if(task.equals("question")){
        question.setEnabled(false);
        trick.setEnabled(true);
        }
    }

    
}
